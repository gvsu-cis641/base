import axios from 'axios';
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Account from './components/account';
import Auth from './components/auth';
import Cart from './components/cart';
import Contact from './components/contact';
import Footer from './components/footer';
import GroceryItemInfo from './components/grocery-item-info';
import Home from './components/home';
import Login from './components/login';
import Orders from './components/orders';
import Signup from './components/signup';
import Wishlist from './components/wishlist';
import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.min.css';

const root = ReactDOM.createRoot(document.getElementById('root'));

axios.interceptors.request.use(function (config) {
    const token = sessionStorage.getItem('jwtToken');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

root.render(
  <React.StrictMode>
      <BrowserRouter>
          <Routes>
              <Route path="/" element={<Auth><Home /></Auth>} />
              <Route path="/item" element={<Auth> <GroceryItemInfo /></Auth>} />
              <Route path="/cart" element={<Auth> <Cart /></Auth>} />
              <Route path="/wishlist" element={<Auth> <Wishlist /></Auth>} />
              <Route path="/account" element={<Auth> <Account /></Auth>} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/orders" element={<Orders/>} />
              <Route path="*" element={<Auth> <Home /> </Auth>} />
          </Routes>
      </BrowserRouter>
      <Footer/>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
