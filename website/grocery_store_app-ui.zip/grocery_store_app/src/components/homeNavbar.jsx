
import axios from 'axios';
import { useEffect, useState } from 'react';
import { Nav, Navbar, NavDropdown } from 'react-bootstrap';
import { FaShoppingCart } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

export default function HomeNavbar() {
    const [categories, setCategories] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        axios
          .get('http://localhost:8080/categories')
          .then((response) => {
              setCategories(response.data);
          })
    }, []);

    function onLogout() {
        sessionStorage.removeItem('jwtToken')
        navigate("/");
    }

    return (
      <Navbar bg="primary" variant="dark" style={{ 'padding': '10px'}}>
          <Navbar.Brand href="home" style={navbarTitle}>Grocery Store</Navbar.Brand>
          <Nav className="me-auto">
              <Nav.Link href="/account">My Account</Nav.Link>
              <Nav.Link href="/orders">My Orders</Nav.Link>
              <Nav.Link href="/wishlist">Wishlist</Nav.Link>
              <NavDropdown title="Categories" id="nav-dropdown">
                  { categories.map((item, index)=> {
                      return <NavDropdown.Item href={`/home?categoryId=${item.id}`}>{item.name}</NavDropdown.Item>
                  })}
              </NavDropdown>
          </Nav>
          <Nav>
              <Nav.Link style={logoutStyle} onClick={onLogout}>Logout</Nav.Link>
              <Nav.Link href="/cart">
                  <FaShoppingCart style={cartStyle}></FaShoppingCart>
              </Nav.Link>
          </Nav>
      </Navbar>
    )
}



const logoutStyle = {
    lineHeight: '30px'
}

const cartStyle = {
    color: 'white',
    fontSize: '20px',
    margin: '5px'
}

const navbarTitle = {
    fontWeight: 'bolder',
    fontSize: '24px',
    lineHeight: '24px'
}
