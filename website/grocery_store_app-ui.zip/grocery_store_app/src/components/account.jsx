
import axios from 'axios';
import { useEffect, useState } from 'react';
import { Alert, Form } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import toast from 'react-simple-toasts';
import HomeNavbar from './homeNavbar';

export default function Account() {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [mailId, setMailId] = useState("");
    const [password, setPassword] = useState("");
    const [phoneNumber, setPhoneNumber] = useState("");
    const [address, setAddress] = useState("");

    const [validated, setValidated] = useState(false);
    const [error, setError]= useState("");

    useEffect(() => {
        axios
          .get('http://localhost:8080/user')
          .then((response) => {
              setFirstName(response.data.firstName);
              setLastName(response.data.lastName);
              setMailId(response.data.email);
              setPhoneNumber(response.data.phone);
              setAddress(response.data.address);
          })
    }, []);

    const onUpdate = (event) => {
        event.preventDefault();
        event.stopPropagation();

        setValidated(true);

        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            return;
        }

        axios
          .post("http://localhost:8080/updateUser", {
              email: mailId,
              password: password,
              firstName: firstName,
              lastName: lastName,
              phone: phoneNumber,
              address: address
          })
          .then((response) => {
              toast('Successfully updated the account')
          }, (err) => {
              setError(err.response.data.message);
          });

    };

    return (
      <div>
      <HomeNavbar/>
      <div style={headerStyle}>Update your information:</div>
          { error ?
            <Alert key={'danger'} variant={'danger'} style={{margin: '20px'}}>
                {error}
            </Alert> : <></>
          }

          <Form style={containerStyle} noValidate validated={validated} onSubmit={onUpdate}>
              <Form.Group  md="4" controlId="firstName">
                  <Form.Label>First name</Form.Label>
                  <Form.Control
                    required
                    type="text"
                    placeholder="Fist Name"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper first name</Form.Control.Feedback>
              </Form.Group>

              <Form.Group  md="4" controlId="lastName" style={groupStyle}>
                  <Form.Label>Last name</Form.Label>
                  <Form.Control
                    required
                    type="text"
                    placeholder="Last name"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper email</Form.Control.Feedback>
              </Form.Group>

              <Form.Group  md="4" controlId="email" style={groupStyle}>
                  <Form.Label>Email</Form.Label>
                  <Form.Control
                    required
                    type="email"
                    placeholder="Email"
                    value={mailId}
                    onChange={(e) => setMailId(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper email</Form.Control.Feedback>
              </Form.Group>

              <Form.Group  md="4" controlId="password" style={groupStyle}>
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper password</Form.Control.Feedback>
              </Form.Group>

              <Form.Group md="4" controlId="phone" style={groupStyle}>
                  <Form.Label>Phone</Form.Label>
                  <Form.Control
                    required
                    type="number"
                    placeholder="Phone"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper phone</Form.Control.Feedback>
              </Form.Group>

              <Form.Group md="4" controlId="address" style={groupStyle}>
                  <Form.Label>Address</Form.Label>
                  <Form.Control
                    required
                    type="text"
                    placeholder="Address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper address</Form.Control.Feedback>
              </Form.Group>

              <Button type="submit" style={groupStyle}>Update</Button>
          </Form>
      </div>
    )
}

const groupStyle = {
    'margin-top': '20px'
}

const buttonStyle = {
    'margin-top': '40px'
}

const headerStyle = {
    'marginTop': '20px',
    'marginLeft': '20px',
    'fontWeight': 'bolder',
    'fontSize': '20px'
}

const containerStyle = {
    'width': '400px',
    'margin': 'auto',
    'display': 'flex',
    'flexDirection': 'column',
    'paddingTop': '20px',
    'paddingBottom': '100px'
}
