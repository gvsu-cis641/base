import axios from 'axios';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { FaHeart, FaShoppingCart, FaTrash } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import toast from 'react-simple-toasts';

export default function GroceryItem({ item, wishlistItem, removeFromWishlist }) {
    function addToCart() {
        axios
          .get('http://localhost:8080/cartAdd?groceryId='+item.id)
          .then((response) => {
            toast('Added to cart')
          }, (err) => {
              toast(err.response.data.message);
          })
    }

    function addToWishList() {
        axios
          .get('http://localhost:8080/wishlistAdd?groceryId='+item.id)
          .then((response) => {
              toast('Added to wishlist')
          }, (err) => {
              toast(err.response.data.message);
          })
    }

    return (
      <Card style={cardStyle}>
          <Link to={{
              pathname: '/item',
          }} state={{item: item }} style={ linkStyle } >
            <Card.Img variant="top" src={item.image} style={imgStyle}/>
          </Link>
          <Card.Body>
              <Card.Title>{item.name}</Card.Title>
              <Card.Subtitle>From {item.seller}</Card.Subtitle>
              <div style={footerStyle}>
                  <div style={priceStyle}>$ {item.price}</div>
                  <div>
                      { !!wishlistItem ?
                        <Button variant="primary" style={buttonStyle} onClick={() => removeFromWishlist(wishlistItem)}>
                            <FaTrash style={cartStyle}/>
                        </Button>
                        :
                        <>
                            <Button variant="primary" style={buttonStyle} onClick={addToWishList}>
                                <FaHeart style={cartStyle}/>
                            </Button>
                            <Button variant="primary" onClick={addToCart}>
                                <FaShoppingCart style={cartStyle}/>
                            </Button>
                        </>
                      }
                  </div>
              </div>
          </Card.Body>
      </Card>
    )
}



const linkStyle = {
    'textDecoration': 'none',
    'color': 'black'
}

const cartStyle = {
    color: 'white',
}

const imgStyle = {
    'height': '250px'
}

const cardStyle = {
    width: '18rem',
    margin: '2rem',
    height: '26rem'
}

const footerStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    position: 'absolute',
    bottom: '10px',
    width: '90%'
}

const priceStyle = {
    lineHeight: '32px',
    fontWeight: 'bolder'
}

const buttonStyle = {
    margin: '2px',
    background: ''
}
