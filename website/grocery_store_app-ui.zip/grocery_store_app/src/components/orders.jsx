
import axios from 'axios';
import { useEffect, useState } from 'react';
import { Container, NavDropdown } from 'react-bootstrap';
import Card from 'react-bootstrap/Card';
import { useNavigate } from 'react-router-dom';
import GroceryCartItem from './grocery-cart-item';
import HomeNavbar from './homeNavbar';

export default function Orders() {
    const [orders, setOrders] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        axios
          .get('http://localhost:8080/orders')
          .then((response) => {
              setOrders(response.data);
              console.log(response.data)
          })
    }, []);

    return (
      <div>
          <HomeNavbar/>
          <Container>
              { orders.map((item, index)=> {
                  return(
                  <Card style={{width: '30em', margin: '1em'}}>
                      <Card.Body>
                          <b>Order Items:</b>
                          {
                              item.orderItems.map((item1, index) => {
                                  return <p>{item1.item.name} x {item1.quantity}</p>
                              })
                          }
                          <p><b>Order date:</b> {item.orderDate}</p>
                          <p><b>Total price:</b> ${item.price} </p>
                      </Card.Body>
                  </Card>
                  )
              })}

          </Container>
      </div>
    )
}
