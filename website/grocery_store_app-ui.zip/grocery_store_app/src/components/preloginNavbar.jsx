import { Nav, Navbar } from 'react-bootstrap';

export default function PreLoginNavbar() {
    return (
      <Navbar bg="primary" variant="dark" style={{ 'padding': '10px'}}>
          <Navbar.Brand href="home" style={navbarTitle}>Grocery Store</Navbar.Brand>
          <Nav className="me-auto">
          </Nav>
          <Nav>
              <Nav.Link href="/login">Login</Nav.Link>
              <Nav.Link href="/signup">Signup</Nav.Link>
          </Nav>
      </Navbar>
    )
}

const cartStyle = {
    color: 'white',
    fontSize: '20px',
    margin: '5px'
}

const navbarTitle = {
    fontWeight: 'bolder',
    fontSize: '24px',
    lineHeight: '24px'
}
