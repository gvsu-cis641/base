import Button from 'react-bootstrap/Button';

export default function GroceryCartItem({ cartItem, incrementCart, decrementCart }) {
    return (
      <div style={containerStyle}>
          <div>
              <img src={cartItem.item.image} style={imgStyle}/>
          </div>

          <div style={{ 'margin-left' : '20px'}}>
              <h3>{cartItem.item.name}</h3>
              <h5>Seller: {cartItem.item.seller}</h5>

              <div>
                  <Button style={buttonStyle} onClick={() => incrementCart(cartItem) }>+</Button>
                  <input style={{width: '30px', 'paddingLeft': '5px'}} value={cartItem.quantity} disabled></input>
                  <Button style={buttonStyle} onClick={() => decrementCart(cartItem)}>-</Button>
              </div>

              <div><b>Price:</b> ${cartItem.item.price * cartItem.quantity}</div>
          </div>

      </div>
    )
}

const buttonStyle = {
    color: 'black',
    backgroundColor: 'white',
    border: 'none'
}

const imgStyle = {
    'width': '150px',
    'height': '150px'
}


const containerStyle = {
    margin: '2rem',
    display: 'flex',
    flexDirection: 'row'
}

