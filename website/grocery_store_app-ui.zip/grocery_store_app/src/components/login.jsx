import axios from 'axios';
import { useState } from 'react';
import { Alert, Col, Form } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import PreLoginNavbar from './preloginNavbar';
import { useNavigate } from 'react-router-dom';

export default function Login() {
    const [userName, setUserName]= useState("");
    const [password, setPassword]= useState("");
    const [validated, setValidated] = useState(false);
    const [error, setError]= useState("");
    const navigate = useNavigate();

    const onLogin = (event) => {
        event.preventDefault();
        event.stopPropagation();

        setValidated(true);

        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            return;
        }


        axios
          .post("http://localhost:8080/login", {
              userName: userName,
              password: password
          })
          .then((response) => {
              console.log(response);
              sessionStorage.setItem('jwtToken', response.data.token);
              navigate('/home');
          }, (err) => {
              event.preventDefault();
              event.stopPropagation();
              setError(err.response.data.message);
          }).catch(() => {
            event.preventDefault();
            event.stopPropagation();
        });

    };

    return (
      <div>
      <PreLoginNavbar/>

      { error ?
        <Alert key={'danger'} variant={'danger'} style={{margin: '20px'}}>
            {error}
        </Alert> : <></>
      }

      <Form style={containerStyle} noValidate validated={validated} onSubmit={onLogin}>
          <Form.Group  md="4" controlId="username">
              <Form.Label>Username</Form.Label>
              <Form.Control
                required
                type="text"
                placeholder="Username"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
              />
              <Form.Control.Feedback type="invalid">Please provide proper username</Form.Control.Feedback>
          </Form.Group>

          <Form.Group md="4" controlId="password" style={groupStyle}>
              <Form.Label>Password</Form.Label>
              <Form.Control
                required
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <Form.Control.Feedback type="invalid">Please provide proper password</Form.Control.Feedback>
          </Form.Group>

          <Button type="submit" style={groupStyle}>Login</Button>
      </Form>
      </div>
    )
}



const groupStyle = {
    'margin-top': '20px'
}

const containerStyle = {
    'width': '400px',
    'margin': 'auto',
    'display': 'flex',
    'flexDirection': 'column',
    'paddingTop': '100px',
    'paddingBottom': '100px'
}
