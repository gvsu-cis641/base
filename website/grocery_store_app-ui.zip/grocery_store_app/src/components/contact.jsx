export default function Contact() {
    return (
      <div>You can contact us at support@grocery.com</div>
    )
}
