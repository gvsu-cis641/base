
import { Tab, Tabs } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import { PaymentInputsWrapper, usePaymentInputs } from 'react-payment-inputs';
import images from 'react-payment-inputs/images';

export default function Payment({orderItems}) {
    const {
        meta,
        wrapperProps,
        getCardImageProps,
        getCardNumberProps,
        getExpiryDateProps,
        getCVCProps
    } = usePaymentInputs();

    return (
      <>
      <Tabs
        defaultActiveKey="credit"
        id="payment"
        className="mb-3"
      >
          <Tab eventKey="credit" title="Credit Card">
              <PaymentInputsWrapper {...wrapperProps}>
                  <svg {...getCardImageProps({ images })} />
                  <input {...getCardNumberProps()} />
                  <input {...getExpiryDateProps()} />
                  <input {...getCVCProps()} />
              </PaymentInputsWrapper>
          </Tab>
          <Tab eventKey="debit" title="Debit Card">
              <PaymentInputsWrapper {...wrapperProps}>
                  <svg {...getCardImageProps({ images })} />
                  <input {...getCardNumberProps()} />
                  <input {...getExpiryDateProps()} />
                  <input {...getCVCProps()} />
              </PaymentInputsWrapper>
          </Tab>
          <Tab eventKey="upi" title="UPI">
              <label htmlFor="upiId">UPI ID: </label><br/>
              <input style={upiStyle} type="text" name="upiId" id="upiId"/>
          </Tab>
        </Tabs>

        <Button style={{marginTop: '2em'}} variant="primary" onClick={() => orderItems(meta)}>Complete payment</Button>
      </>
    );
}

const upiStyle = {
    'margin-top': '10px',
    'width': '100%'
}
