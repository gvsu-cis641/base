import axios from 'axios';
import Button from 'react-bootstrap/Button';
import { useLocation } from 'react-router-dom';
import toast from 'react-simple-toasts';
import HomeNavbar from './homeNavbar';

export default function GroceryItemInfo() {
    const location = useLocation();
    const item = location.state.item;

    function addToCart() {
        axios
          .get('http://localhost:8080/cartAdd?groceryId='+item.id)
          .then((response) => {
              toast('Added to cart')
          }, (err) => {
              toast(err.response.data.message);
          })
    }

    function addToWishList() {
        axios
          .get('http://localhost:8080/wishlistAdd?groceryId='+item.id)
          .then((response) => {
              toast('Added to wishlist')
          }, (err) => {
              toast(err.response.data.message);
          })
    }

    return (
      <div>
      <HomeNavbar/>
      <div style={containerStyle}>
        <div>
            <img src={item.image} style={imgStyle}/>
        </div>

        <div>
            <h2>{item.name}</h2>
            <h5>Seller: {item.seller}</h5>
            <p><b>Price per unit:</b> $ {item.price}</p>
            <p><b>Description:</b> {item.description}</p>

            <div style={buttonContainer}>
                <Button variant="primary" style={{marginRight: '10px'}} onClick={addToCart}>Add to Cart</Button>
                <Button variant="primary" onClick={addToWishList}>Add to wishlist</Button>
            </div>
        </div>
      </div>
      </div>
    )
}

const imgStyle = {
    'height': '400px'
}

const buttonContainer = {
    'display': 'flex',
    'justify-content': 'left',
    'margin-top': '30px'
}

const containerStyle = {
    margin: '2rem',
    display: 'flex',
    flexDirection: 'row',
    'justify-content': 'space-evenly'
}
