import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Home from './components/home';

function App() {
  return (
    <Home></Home>
  );
}

export default App;
